# full ecology routes
