Gallactization — API Routes (ZIP 3)
==================================

This package provides Flask blueprints for Biome and Lifeform APIs.

Files included:
- app/blueprints/api/__init__.py
- app/blueprints/api/biomes.py
- app/blueprints/api/lifeforms.py
- instructions.txt (how to merge and register blueprints)

Endpoints provided (register blueprint at '/api'):
- GET  /api/biomes?page=1&per_page=20&base_type=forest&min_rarity=0.1
- GET  /api/biomes/<id>
- GET  /api/lifeforms/<id>

These endpoints return JSON and use models from ZIP 1 (biomes & lifeforms).
