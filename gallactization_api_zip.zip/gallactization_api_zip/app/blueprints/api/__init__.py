# API package initializer
from flask import Blueprint
api_bp = Blueprint('api', __name__)

# Register sub-blueprints in your app.create_app:
# from app.blueprints.api.biomes import biomes_bp
# from app.blueprints.api.lifeforms import lifeforms_bp
# app.register_blueprint(biomes_bp, url_prefix='/api/biomes')
# app.register_blueprint(lifeforms_bp, url_prefix='/api/lifeforms')
