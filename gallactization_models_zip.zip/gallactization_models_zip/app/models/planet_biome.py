from app.extensions import db
from sqlalchemy.dialects.postgresql import JSONB

class PlanetBiome(db.Model):
    __tablename__ = 'planet_biomes'
    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    planet_id = db.Column(db.String(64), nullable=False, index=True)
    biome_id = db.Column(db.String(64), db.ForeignKey('biomes.id', ondelete='CASCADE'), nullable=False, index=True)
    coverage_percent = db.Column(db.Float, nullable=False, default=0.0)  # 0.0 - 100.0
    metadata = db.Column(JSONB, nullable=False, default=dict)  # any extra info about placement/region

    biome = db.relationship('Biome', backref='planet_mappings')

    def to_dict(self):
        return {
            'id': self.id,
            'planet_id': self.planet_id,
            'biome_id': self.biome_id,
            'coverage_percent': self.coverage_percent,
            'metadata': self.metadata
        }
