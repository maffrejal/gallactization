Gallactization — Models & DB Init (ZIP 1)
========================================

This package adds the new DB models for Biomes, Lifeforms and Planet-Biome mapping,
plus a small script to create tables in your PostgreSQL database using the Flask app context.

Files included:
- app/models/biome.py
- app/models/lifeform.py
- app/models/planet_biome.py
- app/models/__init__.py  (exports models)
- scripts/init_db_models.py (create_all wrapper)
- instructions.txt (how to merge into your project)

IMPORTANT
- This is an **add-on** package: merge files into your existing Flask project root (where `app/` is)
- The scripts assume your `app.create_app()` uses the correct PostgreSQL DATABASE_URL or SQLALCHEMY_DATABASE_URI.
- Backup your project before merging.
