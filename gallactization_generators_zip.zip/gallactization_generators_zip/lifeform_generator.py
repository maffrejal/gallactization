# placeholder lifeform generator (your full code goes here)
