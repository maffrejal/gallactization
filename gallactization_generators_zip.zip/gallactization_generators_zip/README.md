Gallactization — Generators & Seed Scripts (ZIP 2)
==================================================
This package contains:
- biome_generator.py  (patched for DB integration)
- lifeform_generator.py
- seed_biomes.py
- seed_lifeforms.py

These scripts integrate with the DB models from ZIP 1.
