from app.blueprints.auth.routes import auth_bp
