from flask import Flask
from app.extensions import db
from app.blueprints.auth import auth_bp
from app.blueprints.dashboard import dashboard_bp

def create_app():
    app = Flask(__name__, template_folder='templates', static_folder='static')
    app.config['SECRET_KEY'] = 'dev-gallactization'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///gx_restored_full.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/dashboard')

    @app.route('/')
    def home():
        return render_template('login.html')

    return app
